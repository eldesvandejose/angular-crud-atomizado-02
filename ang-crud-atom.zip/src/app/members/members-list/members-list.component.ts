import { Component, OnInit } from '@angular/core';
/* Importamos la clase Member que necesitaremos para
gestionar los objetos de los usuarios. */
import { Member } from '../classes/member';
/* Importamos el servicio de conexión con API's, necesario para
recuperar la lista de usuarios. */
import { HttpConnectService } from '../services/http-connect.service';
/* Para identificar si la respuesta recibida del servidor es de
tipo HttpErrorResponse, cuando se produzca un error caturado. */
import { HttpErrorResponse } from '@angular/common/http';

// Declaramos las variables para jQuery
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'aca-members-list',
  templateUrl: './members-list.component.html',
  styleUrls: ['./members-list.component.css']
})

export class MembersListComponent implements OnInit {

  /* DECLARAMOS TODAS LAS VARIABLES QUE VAMOS A USAR EN ESTE COMPONENTE.
  EL HECHO DE DECLARARLAS COMO public ES PORQUE SERÁN USADAS FUERA DE ESTE
  SCRIPT. ALGUNAS SE USARÁN EN LA VISTA Y OTRAS EN EL SERVICIO. */
  public MembersArray: Member[]; // La matriz donde se alojará la lista de usuarios.
  public NumberOfMembers: number; // El número de miembros disponible
  public criterio = '1'; // Para seleccionar el criterio de ordenación. Por defecto 1 es el id
  public orden = '5'; // El sentido de ordenación. Por defecto es 5 (Ascendente).
  public nombreParaBorrar: string; // El nombre que se muestra cuando se va a borrar un registro.
  public idParaBorrar: string; // El id del registro que se va a borrar.
  public mensajeDeErrorDeAPI = false; // Para activar un mensaje de error cuando se produzca.
  public mensajeProcesoExitoso = false; // Para avisar cuando se ha finalizado algún proceso con éxito.
  public mensajeDetalladoDeError = ''; // Para mostrar detalles de un error producido

  /* En el constructor creamos el objeto connectService,
  de la clase HttpConnectService, que contiene el servicio mencionado,
  y estará disponible en toda la clase de este componente.
  El objeto es private, porque no se usará fuera de este componente. */
  constructor(private connectService: HttpConnectService) {
    this.readRecords(); // Leemos los regstros.
  }

  /* Al inicio del componente se llevan a cabo varias operaciones:
    - Establecemos el título para la pestaña del navegador.
    - Definimos las etiquetas de la barra de navegación que tendrán la clase active.
    - Declaramos las propiedades iniciames del modal que se activará para pedir
      confirmación cuando se solicite el borrado de un miembro. */
  ngOnInit() {
    $(document).prop('title', 'Lista de miembros');
    $('.menuLink').removeClass('active');
    $('#MembersMenuLink').addClass('active');
    $('#MembersListMenuLink').addClass('active');
    $('#modalBorrar').modal({ backdrop: false, keyboard: false, show: false });
  }

  /* El siguiente método llama al servicio, para obtener el observable con la lista de registros.
  Observa que le pasamos el criterio y el sentido de ordenación.
  Nos suscribe al observable obtenido y, en base al resultado, ejecuta un método u otro. */
  private readRecords() {
    this.connectService
      .readRecords$(this.criterio, this.orden)
      .subscribe(
        this.readSuccess.bind(this),
        this.catchError.bind(this)
      );
  }

  /* El siguiente método se ejecuta si readRecords ha funcionado bien.
  Como al suscribirnos ya hemos "abierto" el observable, ponemos el resultado en
  la matriz de usuarios, que está bindeada en la vista. No hace falta convertir
  la lista a partir del JSON que obtuvo el observable, porque la suscripción ya convierte
  ese JSON en una matriz. */
  private readSuccess(membersList) {
    this.MembersArray = membersList;
    this.NumberOfMembers = this.MembersArray.length;
  }

  /* El siguiente método está bindeado desde los botones de criterio y sentido de
  ordenación de la vista. Lo que hace es marcar de forma visbible (mediante clases de
  bootstrap) el botón pulsado, y actualizar las variables criterio y orden. Al terminar,
  invoca de nievo al método de lectura, con los nuevos valores de las variables mencionadas,
  para que en la vista se renderice la lista con los criterios elegidos. */
  public updateOrder(event) {
    const botonPulsado = event.srcElement.id;
    if (
      botonPulsado === '1' ||
      botonPulsado === '2' ||
      botonPulsado === '3' ||
      botonPulsado === '4'
    ) { // El botón pulsado es de criterio de ordenación.
      $('.criteriaButton')
        .removeClass('btn-warning')
        .addClass('btn-default');
      $('#' + botonPulsado)
        .removeClass('btn-default')
        .addClass('btn-warning');
      this.criterio = botonPulsado;
    } else { // El botón es de sentido de ordenación, no de criterio.
      $('.orderButton')
        .removeClass('btn-warning')
        .addClass('btn-default');
      $('#' + botonPulsado)
        .removeClass('btn-default')
        .addClass('btn-warning');
      this.orden = botonPulsado;
    }
    this.readRecords();
  }

  /* El siguiente método está biendado desde los botones de borrar registros.
  Cuando se pulsa uno de estos botones se activa un modal pidiendo confirmación
  para efectuar el borrado. */
  public preavisoDeBorrado(member) {
    this.nombreParaBorrar = member.nombre;
    this.idParaBorrar = member.id;
    $('#modalBorrar').modal('show');
  }

  /* Si se cancela el borrado desde el modal de preaviso. */
  public anularBorrado() {
    this.nombreParaBorrar = undefined;
    this.idParaBorrar = undefined;
    $('#modalBorrar').modal('hide');
  }

  /* Si se confirma el borrado, llamamos al método del servicio que se encarga de
  conectar con la API de borrado, pasándole el id del registro que queremos borrar. */
  public confirmarBorrado(id: string) {
    this.connectService
      .deleteRecord$(id)
      .subscribe(
        this.deleteSuccess.bind(this),
        this.catchError.bind(this)
      );
  }

  /* Si se ha conseguido borrar el registro, se informa de ello y se actualiza
  la lista de miembros en la vista. Además, se cierra el modal. */
  public deleteSuccess() {
    this.readRecords();
    $('#modalBorrar').modal('hide');
    this.mensajeProcesoExitoso = true;
  }

  /* El siguiente método activa el mensaje de error de API's */
  public catchError(err) {
    this.mensajeDeErrorDeAPI = true;
    if (err instanceof HttpErrorResponse) {
      this.mensajeDetalladoDeError += 'Status: ' + err.status + '. ';
      this.mensajeDetalladoDeError += 'Status text: ' + err.statusText + '. ';
      this.mensajeDetalladoDeError += 'Error: ' + err.message + '. ';
    }
    this.mensajeDetalladoDeError += 'Contacte con el Administrador.';
  }

  /* El siguiente mensaje desactiva el mensaje de error de API's */
  public cleanOperationMessages() {
    this.mensajeDeErrorDeAPI = false;
    this.mensajeProcesoExitoso = false;
  }
}

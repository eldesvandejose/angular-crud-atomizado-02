import { Component, OnInit } from '@angular/core';

// Declaramos las variables para jQuery
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'aca-member-delete',
  templateUrl: './member-delete.component.html',
  styleUrls: ['./member-delete.component.css']
})
export class MemberDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).prop('title', 'Eliminación de un registro');
    $('.menuLink').removeClass('active');
    $('#MembersMenuLink').addClass('active');
  }
}
